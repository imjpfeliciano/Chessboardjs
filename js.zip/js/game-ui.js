(function() {

  var board, moveHandler;

  function init() {
    board = window.board = new ChessBoard('board', {draggable: true, onDrop: pieceDrop});
  }

  function pieceDrop(source, target, piece, newPos, oldPos, orientation) {
    if (moveHandler && !moveHandler(source, target)) return 'snapback';
  }


  document.addEventListener('DOMContentLoaded', init);

  window.GameUI = {
    setPieces: function (pieces) {
      board.clear();
      board.position(pieces)
    },
    setMoveHandler: function(handler) {
     moveHandler = handler;
    }
  }
}());